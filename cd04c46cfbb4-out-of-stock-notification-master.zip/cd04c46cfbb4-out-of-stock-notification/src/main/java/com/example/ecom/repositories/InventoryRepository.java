package com.example.ecom.repositories;

public interface InventoryRepository {

}
