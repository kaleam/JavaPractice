package com.example.ecom.exceptions;

public class ProductInStockException extends Exception {
    public ProductInStockException(String message) {
        super(message);
    }
}
