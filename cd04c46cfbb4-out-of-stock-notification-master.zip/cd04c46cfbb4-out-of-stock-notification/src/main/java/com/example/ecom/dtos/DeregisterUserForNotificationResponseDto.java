package com.example.ecom.dtos;

import lombok.Data;

@Data
public class DeregisterUserForNotificationResponseDto {
    private ResponseStatus responseStatus;
}
