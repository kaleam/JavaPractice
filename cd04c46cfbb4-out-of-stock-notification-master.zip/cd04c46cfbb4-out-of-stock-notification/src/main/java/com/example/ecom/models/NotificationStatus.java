package com.example.ecom.models;

public enum NotificationStatus {
    PENDING, SENT;
}
