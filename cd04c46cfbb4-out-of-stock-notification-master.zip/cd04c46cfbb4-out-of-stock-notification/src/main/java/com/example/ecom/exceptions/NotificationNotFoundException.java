package com.example.ecom.exceptions;

public class NotificationNotFoundException extends Exception{
    public NotificationNotFoundException(String message) {
        super(message);
    }
}
